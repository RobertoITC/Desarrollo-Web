
import React, {useEffect,useState} from "react";
import {useParams} from "react-router-dom";
import usersSvg from "../../assets/users.svg";
import PrevDescription from "./components/PrevDescription.jsx";
import CardInfo from "./components/CardInfo.jsx";
import CardDescPresc from "./components/CardDescPresc.jsx";

const Users = () => {

    const [form, setForm] = useState({
        description:'',
        prescription:'',

        createat:'',
    });

    const [contextForm, setContextForm] = useState({
        message:'',
        context:'',
    });


    const [descriptions, setDescriptions]=useState([]);


    const [user, setUser] = useState([]);

    const{id}=useParams();

    const UrlLocalhost = 'http://localhost:3000/';


    const fetchUsersById=async () =>{
        const response = await fetch(UrlLocalhost+'users/'+id);
        const data = await response.json();
        setUser(data);
        return data;
    }



    const fetchDescription=async () =>{
        console.log("ID from users",id);
        console.log("Fetch Description");
        const res = await fetch(UrlLocalhost+'description/'+id);
        const data = await res.json();
        console.log(data);
        setDescriptions(data);

    };
    useEffect(() => {
        fetchDescription();
        fetchFeedback();
        fetchUsersById()
    }, []);

    const fetchFeedback=async () =>{
        console.log("ID from users",id);
        console.log("Fetch Feedback");
        const res = await fetch(UrlLocalhost+'feedback/'+id);
        const data = await res.json();
        console.log(data);
    }

    const handleInputChange=(e)=>{
        const{name, value} = e.target;
        const newForm={
            ...form,
            [name]:value
        }
        setForm(newForm);
    };

    const handleInputContextChange=(e)=>{
        const{name, value} = e.target;
        const newContextForm={
            ...contextForm,
            [name]:value
        }
        console.log(newContextForm);
        setContextForm(newContextForm);
    };



    const handleGenerateHelp = async() => {
        const prompt={
            prompt:form.description,
        }
        console.log(prompt);
        const response = await fetch(UrlLocalhost+'chat/',{
            method: 'POST',
            headers:{
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(prompt)
        })

        const data=await response.json();
        console.log(data);
        setForm({...form,prescription:data.response});
        return data;

    };

    const handleGenerateContextHelp = async() => {
        const message={
            message:contextForm.message,
        }
        console.log(message);
        const response = await fetch(UrlLocalhost+'chat/context',{
            method: 'POST',
            headers:{
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(message)
        })

        const data=await response.json();
        console.log(data);
        setContextForm({...contextForm, context:data.response});
        console.log(contextForm)

        return data;

    };

    const handleSaveGeneration = async()=>{
        const response = await fetch(UrlLocalhost+'description/'+id,{
            method: 'POST',
            headers:{
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(form)
        })

        if (response.status === 200) {
            alert('Save Succesful');

        } else {
            alert('Error on save');
        }
    }



    return (
<div className={'overflow-x-auto'} >
        <div className={'overflow-auto'}>
            <PrevDescription description={descriptions}/>
        </div>
    <div className={'flex flex-row justify-center bg-[#399c7f]/20'}>
        <div className={'flex flex-col h-screen justify-center'}>
            <CardInfo user={user}/>
            </div>


            <div className={'flex flex-col justify-center'}>
                <div className={'flex flex-row justify-end'}>
                    <div className={'m-4'}>
                        <p className={'text-lg font-bold'}>Description</p>
                        <textarea
                            value={form.description}
                            name={'description'}
                            onChange={handleInputChange}
                            className={'w-[300px] h-[400px] border-2 border-[#399c7f]/80 rounded-md'}

                        />
                    </div>
                    <div className={'m-4'}>
                        <p className={'text-lg font-bold'}>Prescription </p>
                        <textarea
                            value={form.prescription}
                            name={'prescription'}
                            onChange={handleInputChange}
                            className={'w-[300px] h-[400px] border-2 border-[#399c7f]/80 rounded-md'}
                        />
                    </div>
                    <div className={'m-4 flex flex-col'}>
                        <p className={'text-lg font-bold'}>Context Question RAG </p>
                        <textarea
                            value={contextForm.message}
                            name={'message'}
                            onChange={handleInputContextChange}
                            className={'w-[200px] h-[200px] border-2 border-[#399c7f]/80 rounded-md'}
                        />
                        <button
                            style={{
                                height: '2.5rem',
                                width: 'fit-content',
                                marginTop: '8%',
                                backgroundColor: '#399c7e',
                                color: 'white',
                                border: 'none',
                                fontSize: 'medium',
                                borderRadius: '6px',
                                cursor: 'pointer',
                                padding: '10px',

                            }}
                            type={'submit'}
                            onClick={handleGenerateContextHelp}


                        >Generate RAG answer
                        </button>
                    </div>
                    <div className={'m-4'}>
                        <p className={'text-lg font-bold'}>Context Question RAG </p>
                        <textarea
                            value={contextForm.context}
                            name={'context'}
                            onChange={handleInputContextChange}
                            className={'w-[200px] h-[200px] border-2 border-[#399c7f]/80 rounded-md'}
                        />
                    </div>
                </div>
                <div className={'flex justify-center'}>
                    <button
                        style={{
                            height: '2.5rem',
                            width: '5rem',
                            marginTop: '2%',
                            backgroundColor: '#399c7e',
                            color: 'white',
                            border: 'none',
                            fontSize: 'medium',
                            borderRadius: '6px',
                            cursor: 'pointer',
                        }}
                        type={'submit'}
                        onClick={handleGenerateHelp}


                    >Generate
                    </button>
                    <button
                        style={{
                            height: '2.5rem',
                            width:'5rem',
                            marginTop: '2%',
                            color: 'white',
                            backgroundColor: '#399c7f',
                            border: 'none',
                            fontSize: 'medium',
                            borderRadius: '6px',
                            cursor: 'pointer',
                            marginLeft: '1rem',
                        }}
                        type={'submit'}
                        onClick={handleSaveGeneration}


                    >Save
                    </button>

                </div>
            </div>


        </div>

</div>
    )


}

export default Users;